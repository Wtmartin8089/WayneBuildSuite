#!/bin/bash

echo "🔧 Installing Wayne Build Suite system-wide..."

sudo mkdir -p /opt/waynebuild
sudo cp src/* /opt/waynebuild
sudo cp waynebuild /usr/local/bin/
sudo chmod +x /usr/local/bin/waynebuild

echo "✅ Installed! Type 'waynebuild' to launch."
