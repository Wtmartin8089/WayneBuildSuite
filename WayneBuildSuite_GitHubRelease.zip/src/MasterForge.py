from kivymd.app import MDApp
from kivymd.uix.label import MDLabel

class MasterForgeApp(MDApp):
    def build(self):
        return MDLabel(text="Master Forge Loaded", halign="center")

if __name__ == "__main__":
    MasterForgeApp().run()
