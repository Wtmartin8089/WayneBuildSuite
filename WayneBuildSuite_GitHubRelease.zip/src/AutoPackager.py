from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
from kivymd.uix.menu import MDDropdownMenu
from datetime import datetime
import subprocess
import os
import shutil

class AutoPackagerApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Green"

        layout = MDBoxLayout(orientation="vertical", padding=20, spacing=10)

        self.path_input = MDTextField(hint_text="Path to project directory", size_hint_y=None, height=50)
        self.status = MDLabel(text="Choose a package type to build", halign="left")

        zip_btn = MDRaisedButton(text="Build ZIP", size_hint_y=None, height=50)
        zip_btn.bind(on_release=self.build_zip)

        deb_btn = MDRaisedButton(text="Build DEB", size_hint_y=None, height=50)
        deb_btn.bind(on_release=self.build_deb)

        apk_btn = MDRaisedButton(text="Build APK", size_hint_y=None, height=50)
        apk_btn.bind(on_release=self.build_apk)

        layout.add_widget(self.path_input)
        layout.add_widget(zip_btn)
        layout.add_widget(deb_btn)
        layout.add_widget(apk_btn)
        layout.add_widget(self.status)

        return layout

    def build_zip(self, *args):
        path = self.path_input.text.strip()
        if not os.path.isdir(path):
            self.status.text = "❌ Invalid path."
            return
        os.makedirs("dist", exist_ok=True)
        out = os.path.join("dist", f"waynebuild_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip")
        subprocess.run(["zip", "-r", out, path])
        self.status.text = f"✅ ZIP created: {out}"

    def build_deb(self, *args):
        src = self.path_input.text.strip()
        if not os.path.isdir(src):
            self.status.text = "❌ Invalid path."
            return

        os.makedirs("dist", exist_ok=True)
        pkg_dir = os.path.abspath("temp_deb/waynebuild")
        control_dir = os.path.abspath("temp_deb/DEBIAN")
        os.makedirs(pkg_dir, exist_ok=True)
        os.makedirs(control_dir, exist_ok=True)

        # Copy source code
        shutil.copytree(src, pkg_dir, dirs_exist_ok=True)

        # Write control file
        control_file = os.path.join(control_dir, "control")
        with open(control_file, "w") as f:
            f.write("Package: waynebuild\nVersion: 1.0\nArchitecture: all\nMaintainer: Wayne\nDescription: Wayne Build Suite App\n")

        # Build .deb
        out = os.path.join("dist", f"waynebuild_{datetime.now().strftime('%Y%m%d_%H%M%S')}.deb")
        result = subprocess.run(["dpkg-deb", "--build", "temp_deb", out])
        if result.returncode == 0:
            self.status.text = f"✅ DEB created: {out}"
        else:
            self.status.text = "❌ Failed to build .deb"

        shutil.rmtree("temp_deb")

    def build_apk(self, *args):
        src = self.path_input.text.strip()
        if not os.path.isdir(src):
            self.status.text = "❌ Invalid path."
            return
        try:
            result = subprocess.run(["buildozer", "android", "debug"], cwd=src)
            if result.returncode == 0:
                self.status.text = "✅ APK build succeeded (check bin/ folder)"
            else:
                self.status.text = "❌ APK build failed (see console output)"
        except FileNotFoundError:
            self.status.text = "⚠️ Buildozer not found. Install it first."

if __name__ == "__main__":
    AutoPackagerApp().run()
