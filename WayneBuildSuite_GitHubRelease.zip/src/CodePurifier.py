from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
from kivymd.uix.menu import MDDropdownMenu
from kivy.metrics import dp
import subprocess
import os

class CodePurifierApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Teal"

        self.tool = "black"
        self.layout = MDBoxLayout(orientation="vertical", padding=20, spacing=10)

        self.path_input = MDTextField(hint_text="Path to .py file or folder", size_hint_y=None, height=50)
        self.status = MDLabel(text="Ready to purify using black.", halign="left")

        menu_items = [
            {"text": "black", "viewclass": "OneLineListItem", "on_release": lambda x="black": self.set_tool(x)},
            {"text": "autopep8", "viewclass": "OneLineListItem", "on_release": lambda x="autopep8": self.set_tool(x)},
            {"text": "ruff", "viewclass": "OneLineListItem", "on_release": lambda x="ruff": self.set_tool(x)},
        ]
        self.menu = MDDropdownMenu(caller=None, items=menu_items, width_mult=4)

        tool_btn = MDRaisedButton(text="Select Tool", size_hint_y=None, height=50)
        tool_btn.bind(on_release=self.menu.open)
        self.menu.caller = tool_btn

        run_btn = MDRaisedButton(text="Purify", size_hint_y=None, height=50)
        run_btn.bind(on_release=self.purify)

        self.layout.add_widget(self.path_input)
        self.layout.add_widget(tool_btn)
        self.layout.add_widget(run_btn)
        self.layout.add_widget(self.status)

        return self.layout

    def set_tool(self, tool_name):
        self.tool = tool_name
        self.status.text = f"Selected tool: {tool_name}"
        self.menu.dismiss()

    def purify(self, *args):
        path = self.path_input.text.strip()
        if not os.path.exists(path):
            self.status.text = "❌ Path not found."
            return

        try:
            if os.path.isfile(path):
                result = subprocess.run([self.tool, path], capture_output=True, text=True)
            elif os.path.isdir(path):
                result = subprocess.run([self.tool, path], capture_output=True, text=True)
            else:
                self.status.text = "⚠️ Invalid path."
                return

            if result.returncode == 0:
                self.status.text = f"✅ Purified using {self.tool}."
            else:
                self.status.text = f"⚠️ Tool error: {result.stderr}"
        except Exception as e:
            self.status.text = f"❌ Exception: {e}"
