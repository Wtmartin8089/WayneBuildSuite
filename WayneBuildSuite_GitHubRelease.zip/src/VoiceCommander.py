from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton
import subprocess

try:
    import speech_recognition as sr
except ImportError:
    sr = None

class VoiceApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Purple"

        layout = MDBoxLayout(orientation="vertical", padding=20, spacing=10)
        self.status = MDLabel(text="🎙️ Waiting for voice command...", halign="center")
        btn = MDRaisedButton(text="Start Listening", on_release=self.listen)
        layout.add_widget(self.status)
        layout.add_widget(btn)
        return layout

    def listen(self, *args):
        if not sr:
            self.status.text = "❌ speech_recognition not installed."
            return

        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            self.status.text = "🎤 Listening..."
            try:
                audio = recognizer.listen(source, timeout=5)
                command = recognizer.recognize_google(audio).lower()
                self.status.text = f"✅ Heard: {command}"
                self.route_command(command)
            except sr.UnknownValueError:
                self.status.text = "❌ Could not understand audio."
            except sr.RequestError:
                self.status.text = "❌ Could not connect to recognition service."
            except Exception as e:
                self.status.text = f"⚠️ {e}"

    def route_command(self, command):
        if "forge" in command:
            subprocess.Popen(["python3", "MasterForge.py"])
            self.status.text = "🚀 Launching Master Forge..."
        elif "purifier" in command:
            subprocess.Popen(["python3", "CodePurifier.py"])
            self.status.text = "🚀 Launching Code Purifier..."
        elif "encrypt" in command:
            subprocess.Popen(["python3", "AppEncryptor.py"])
            self.status.text = "🚀 Launching App Encryptor..."
        elif "wizard" in command:
            subprocess.Popen(["python3", "GUIWizard.py"])
            self.status.text = "🚀 Launching GUI Wizard..."
        else:
            self.status.text = "🤔 Command not recognized."

if __name__ == "__main__":
    VoiceApp().run()
