from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
import os
import compileall
import subprocess

class EncryptorApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Red"

        layout = MDBoxLayout(orientation="vertical", padding=20, spacing=10)
        self.input = MDTextField(hint_text="Path to .py file", size_hint_y=None, height=50)
        self.status = MDLabel(text="Awaiting target...", halign="left")

        obf_btn = MDRaisedButton(text="Obfuscate", size_hint_y=None, height=50)
        obf_btn.bind(on_release=self.obfuscate)

        compile_btn = MDRaisedButton(text="Compile to .pyc", size_hint_y=None, height=50)
        compile_btn.bind(on_release=self.compile_to_pyc)

        delete_btn = MDRaisedButton(text="Destroy Original", size_hint_y=None, height=50)
        delete_btn.bind(on_release=self.destroy_original)

        layout.add_widget(self.input)
        layout.add_widget(obf_btn)
        layout.add_widget(compile_btn)
        layout.add_widget(delete_btn)
        layout.add_widget(self.status)

        return layout

    def obfuscate(self, *args):
        path = self.input.text.strip()
        if not os.path.isfile(path):
            self.status.text = "❌ Invalid file path."
            return

        os.makedirs("encrypted", exist_ok=True)
        output_path = os.path.join("encrypted", os.path.basename(path).replace(".py", "_obf.py"))

        try:
            result = subprocess.run([
                "pyminifier", "--obfuscate", "--replacement-length=4",
                "--gzip", "--nominify", "--outfile", output_path, path
            ], capture_output=True, text=True)

            if result.returncode == 0:
                self.status.text = f"✅ Obfuscated to {output_path}"
            else:
                self.status.text = f"⚠️ Error: {result.stderr}"
        except Exception as e:
            self.status.text = f"❌ Exception: {e}"

    def compile_to_pyc(self, *args):
        path = self.input.text.strip()
        if not os.path.isfile(path):
            self.status.text = "❌ Invalid file path."
            return

        try:
            compileall.compile_file(path, force=True, quiet=1)
            self.status.text = "✅ Compiled to .pyc"
        except Exception as e:
            self.status.text = f"❌ Compilation error: {e}"

    def destroy_original(self, *args):
        path = self.input.text.strip()
        if os.path.isfile(path):
            os.remove(path)
            self.status.text = "🔥 Original file destroyed."
        else:
            self.status.text = "❌ File not found."

if __name__ == "__main__":
    EncryptorApp().run()
