from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.clock import Clock
from kivy.uix.screenmanager import ScreenManager, Screen
import startup
import subprocess

class LockerDashboard(Screen):
    pass

class LockerApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Orange"
        self.sm = ScreenManager()
        self.sm.add_widget(startup.StartupScreen(name="startup"))
        self.sm.add_widget(LockerDashboard(name="dashboard"))
        return self.sm

    def on_start(self):
        Clock.schedule_once(self.go_to_dashboard, 5)

    def go_to_dashboard(self, *args):
        self.sm.current = "dashboard"

    def launch_master_forge(self):
        subprocess.Popen(["python3", "MasterForge.py"])

    def launch_code_purifier(self):
        subprocess.Popen(["python3", "CodePurifier.py"])

    def launch_app_encryptor(self):
        subprocess.Popen(["python3", "AppEncryptor.py"])

    def launch_gui_wizard(self):
        subprocess.Popen(["python3", "GUIWizard.py"])

    def launch_voice_commander(self):
        subprocess.Popen(["python3", "VoiceCommander.py"])

    def launch_auto_packager(self):
        subprocess.Popen(["python3", "AutoPackager.py"])

LockerApp().run()
