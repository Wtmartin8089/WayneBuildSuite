from kivymd.app import MDApp
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.widget import Widget
from kivy.core.window import Window
from kivy.uix.popup import Popup
import os

class GUIWizardApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "BlueGray"
        self.layout_data = []

        root = MDBoxLayout(orientation="vertical", spacing=10, padding=10)

        toolbar = MDBoxLayout(size_hint_y=None, height=50, spacing=10)
        add_label = MDRaisedButton(text="Label", on_release=self.add_label)
        add_button = MDRaisedButton(text="Button", on_release=self.add_button)
        add_text = MDRaisedButton(text="TextField", on_release=self.add_textfield)
        save_btn = MDRaisedButton(text="Save", on_release=self.save_layout)
        clear_btn = MDRaisedButton(text="Clear", on_release=self.clear_layout)

        toolbar.add_widget(add_label)
        toolbar.add_widget(add_button)
        toolbar.add_widget(add_text)
        toolbar.add_widget(save_btn)
        toolbar.add_widget(clear_btn)

        self.canvas_area = MDFloatLayout()
        root.add_widget(toolbar)
        root.add_widget(self.canvas_area)

        return root

    def add_widget_to_canvas(self, widget_type, text):
        x, y = 100 + len(self.canvas_area.children) * 10, 400
        if widget_type == "Label":
            widget = MDLabel(text=text, pos=(x, y), size_hint=(None, None))
        elif widget_type == "Button":
            widget = MDRaisedButton(text=text, pos=(x, y), size_hint=(None, None))
        elif widget_type == "TextField":
            widget = MDTextField(hint_text=text, pos=(x, y), size_hint=(.3, None), height=48)
        self.canvas_area.add_widget(widget)
        self.layout_data.append((widget_type, widget.text if hasattr(widget, 'text') else widget.hint_text, widget.pos))

    def add_label(self, *args):
        self.add_widget_to_canvas("Label", "New Label")

    def add_button(self, *args):
        self.add_widget_to_canvas("Button", "Click Me")

    def add_textfield(self, *args):
        self.add_widget_to_canvas("TextField", "Enter text")

    def clear_layout(self, *args):
        self.canvas_area.clear_widgets()
        self.layout_data = []

    def save_layout(self, *args):
        os.makedirs("gui_output", exist_ok=True)
        with open("gui_output/generated_layout.kv", "w") as kv:
            kv.write("<GeneratedScreen>:\n    MDFloatLayout:\n")
            for wtype, text, pos in self.layout_data:
                if wtype == "Label":
                    kv.write(f"        MDLabel:\n            text: '{text}'\n            pos: {pos}\n")
                elif wtype == "Button":
                    kv.write(f"        MDRaisedButton:\n            text: '{text}'\n            pos: {pos}\n")
                elif wtype == "TextField":
                    kv.write(f"        MDTextField:\n            hint_text: '{text}'\n            pos: {pos}\n")
        with open("gui_output/main.py", "w") as py:
            py.write("from kivymd.app import MDApp\nfrom kivy.lang import Builder\n\nclass GeneratedApp(MDApp):\n")
            py.write("    def build(self):\n        return Builder.load_file('generated_layout.kv')\n\nGeneratedApp().run()\n")

        popup = Popup(title="Saved", content=MDLabel(text="Layout saved to gui_output/"), size_hint=(None, None), size=(400, 200))
        popup.open()

if __name__ == "__main__":
    GUIWizardApp().run()
