from kivy.uix.screenmanager import Screen
from kivymd.uix.label import MDLabel
from kivy.clock import Clock

class StartupScreen(Screen):
    def on_enter(self):
        self.label = MDLabel(
            text="",
            halign="center",
            valign="center",
            font_style="H6",
            theme_text_color="Custom",
            text_color=(1, 0.5, 0, 1),
        )
        self.add_widget(self.label)
        self.messages = [
            "Accessing Digital Weapons Locker...",
            "Authenticating...",
            "Authentication Successful.",
            "Welcome, Master Wayne.",
        ]
        self.current_message = 0
        Clock.schedule_once(self.type_message, 0.5)

    def type_message(self, dt):
        if self.current_message < len(self.messages):
            self.label.text += self.messages[self.current_message] + "\n"
            self.current_message += 1
            Clock.schedule_once(self.type_message, 1)
